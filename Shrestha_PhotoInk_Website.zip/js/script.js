function toggleMenu() {
  const navList = document.querySelector("nav ul");
  navList.classList.toggle("showing");
}